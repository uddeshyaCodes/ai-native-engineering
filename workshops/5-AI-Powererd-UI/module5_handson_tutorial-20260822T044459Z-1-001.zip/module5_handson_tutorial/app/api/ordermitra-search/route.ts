import { notImplementedChatResponse } from "@/lib/stub-response";

export async function POST(_req: Request) {
  // ── TODO (Chapter 3 · Agentic Patterns) ─────────────────────────
  // Wire the searchOrders tool (lib/tools/search-orders.ts) into a streamText call.
  // Delete the stub import/call below once implemented.
  // ────────────────────────────────────────────────────────────────
  return notImplementedChatResponse(
    "OrderMitra can't search yet implement app/api/ordermitra-search/route.ts (Chapter 3)."
  );
}

export async function POST() {
  // ── TODO (Chapter 2 · Confidence Indicator, second example) ─────
  // Same pattern as app/api/answer/route.ts.
  // applied to a different question worth doing twice before it clicks.
  // ────────────────────────────────────────────────────────────────
  return Response.json({
    summary: "TODO: implement app/api/order-summary/route.ts (Chapter 2).",
    confidence: "low",
    ordersReferenced: 0,
  });
  
}

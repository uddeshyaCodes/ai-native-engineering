export async function GET() {
  // ──────────────────── TODO (Chapter 1 · SSE) ──────────────────────
  // Replace the whole stream below once implemented. This placeholder
  // just sends one message so the page never hangs on a blank screen.
  // ──────────────────────────────────────────────────────────────────
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(`data: TODO: implement the counter route\n\n`);
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}

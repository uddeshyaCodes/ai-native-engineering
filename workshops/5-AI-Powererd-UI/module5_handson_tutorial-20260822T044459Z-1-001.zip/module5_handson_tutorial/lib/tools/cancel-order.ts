import { tool } from "ai";
import { z } from "zod";

// ── TODO (Chapter 4 · Human-in-the-Loop UI) ───────────────────────
//
// IMPORTANT read before you prompt: do NOT give this tool an
// execute() function. A tool with execute() runs the instant the
// model calls it, which would skip the confirmation card entirely.
// Leaving execute() off is what makes this a human-in-the-loop tool
// the AI SDK pauses and waits for the UI's Confirm click instead of
// running automatically.
//
// Put the actual cancellation logic in a separate exported function
// (e.g. runCancelOrder), called only from app/api/run-cancel-order
// after a human confirms not from inside the tool itself.
// ──────────────────────────────────────────────────────────────────
export const cancelOrder = tool({
  description:
    "Cancel an order by its ID. DESTRUCTIVE this permanently changes " +
    "the order's status to cancelled. Requires human confirmation before " +
    "it runs; you are only proposing this action, not performing it.",
  inputSchema: z.object({
    orderId: z.string().describe("The ID of the order to cancel"),
  }),
  // No execute() see comment above.
});

export async function runCancelOrder({ orderId }: { orderId: string }) {
  // TODO: implement the actual Prisma update:
  //   prisma.order.update({ where: { id: orderId }, data: { status: "cancelled" } })
  void orderId;
  return {
    note: "TODO: implement runCancelOrder in lib/tools/cancel-order.ts (Chapter 4). No order was actually cancelled.",
  };
}

import { z } from "zod";
import { tool } from "ai";

// ────────────── TODO (Chapter 3 | Agentic Patterns) ───────────────
//
// Replace the placeholder inputSchema/execute below. Keep the
// `description` it's what steers the model to use this tool at all.
//
// ──────────────────────────────────────────────────────────────────
export const searchOrders = tool({
  description:
    "Search orders by customer name or status. Use this whenever the " +
    "user asks about specific orders.",
  inputSchema: z.object({
    customerName: z.string().optional(),
    status: z.string().optional(),
  }),
  execute: async () => {
    return {
      note: "TODO: implement lib/tools/search-orders.ts (Chapter 3). This tool currently returns no real data.",
    };
  },
});
